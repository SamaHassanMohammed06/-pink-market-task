window.addEventListener("load", function () {

    let xhr = new XMLHttpRequest();

    let id = new URLSearchParams(location.search).get("id");

    xhr.onload = () => {

        if (xhr.status === 200) {

            let data = JSON.parse(xhr.responseText);

            let product = data.find(item => item.id == id);

            let wrapper = document.getElementById("wrapper");

            let details = `
            <div class="img">
                <img src="${product.image}" alt="${product.name}">
            </div>

            <div class="details">
                <p class="head">Name:<br>${product.name}</p>
                <p class="head">Description:<br>${product.description}</p>
                <p class="head">Price:<br>${product.price}</p>
                <p class="head">Stock:<br>${product.stock}</p>
            </div>
            `;

            wrapper.innerHTML = details;
        }
    };

    xhr.open("GET", "Shoes.json");
    xhr.send();

});
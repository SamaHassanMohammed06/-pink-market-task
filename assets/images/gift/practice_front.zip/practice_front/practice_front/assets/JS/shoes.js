window.addEventListener("load", function () {

    let xhr = new XMLHttpRequest();

    xhr.onload = () => {
        console.log(xhr.status);
       console.log(xhr.responseText);
        if (xhr.readyState === 4 && xhr.status === 200) {

            let data = JSON.parse(xhr.responseText);

            const cards = document.getElementById("cards");

            let card = "";

            for (let item of data) {
                card += `
                <div class="card">
                    <img src="${item.image}">
                    <br>
                    <p>${item.name}</p>
                    <p>${item.price}</p>
           <button onclick="window.location.href='details.html?id=${item.id}'">View Detail</button>
                </div>`;
            }

            cards.innerHTML = card;
        }
    };

    xhr.open("GET", "Shoes.json");
    xhr.send();

 
});